package com.gi.beans;

public class GasStation {
	public double getFuelPrice(String fuelType, int quantity) {
		return 120.25 * quantity;
	}
}
